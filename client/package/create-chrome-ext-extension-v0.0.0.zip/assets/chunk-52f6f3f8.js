console.info("chrome-ext template-svelte-js content script");
