(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/chunk-52f6f3f8.js")
    );
  })().catch(console.error);

})();
